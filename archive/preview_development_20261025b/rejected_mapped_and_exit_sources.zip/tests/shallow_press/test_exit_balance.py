import numpy as np
import pytest


def test_climbing_wheel_gains_torque_without_changing_each_side_total():
    from ddevsim.strategies.shallow_press.traction import redistribute_exit_torque
    t=np.array([-50.,-50.,-50.,-50.]);load=np.full(4,3300.);radius=np.full(4,.263)
    out=redistribute_exit_torque(t,[400,0,0,400],load,.7,radius,1.)
    assert out==pytest.approx([150,-250,-250,150])
    assert out[[0,2]].sum()==pytest.approx(-100.)
    assert out[[1,3]].sum()==pytest.approx(-100.)
    assert redistribute_exit_torque(t,[400]*4,load,.7,radius,0)==pytest.approx(t)


def test_redistribution_respects_load_capacity_and_never_drives_lost_wheel():
    from ddevsim.strategies.shallow_press.traction import redistribute_exit_torque
    t=np.array([0.,490.,-100.,0.]);load=np.array([0.,5000.,3300.,3300.]);radius=np.full(4,.263)
    out=redistribute_exit_torque(t,[500]*2+[0]*2,load,.7,radius,1.)
    assert out[0]==0 and out[1]<=500
    assert out[[0,2]].sum()==pytest.approx(-100.)
    assert out[[1,3]].sum()==pytest.approx(490.)


def test_lower_configured_torque_limit_preserves_braking_sum_before_projection():
    from ddevsim.strategies.shallow_press.traction import redistribute_exit_torque
    out=redistribute_exit_torque(np.full(4,-50.),[400,0,0,400],np.full(4,3300.),.7,np.full(4,.263),1.,torque_limit_nm=100.)
    assert np.max(abs(out))<=100.
    assert out[[0,2]].sum()==pytest.approx(-100.)
    assert out[[1,3]].sum()==pytest.approx(-100.)
