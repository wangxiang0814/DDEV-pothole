import numpy as np
import pytest


def test_complete_seat_map_uses_low_and_high_jounce_slopes_and_extrapolation():
    from ddevsim.strategies.shallow_press.force_preview import seat_kinematics
    g,mu=seat_kinematics(np.array([-.02,.025,-.02,.025]))
    assert g==pytest.approx([-.0130288,.01758897,-.01594,.021519])
    assert mu==pytest.approx([.65144,.781746,.797,.9564])


def test_flat_initialization_has_no_preview_force_and_extension_restores_generalized_support():
    from ddevsim.strategies.shallow_press.force_preview import MappedForcePreview,seat_kinematics
    j=np.array([.038,.022,.043,.033]);s=np.array([.05]*4);f=np.array([1500,1500,3000,3000])
    model=MappedForcePreview(j,s,f)
    zero=np.zeros(4)
    assert model.step(zero,zero,zero,False)['force_n']==pytest.approx(zero)
    r=np.full(4,-.10);out=model.step(r,zero,zero,False)
    _,mu0=seat_kinematics(j)
    assert out['motion_ratio']*(out['passive_spring_n']+out['force_n'])==pytest.approx(mu0*f)
    assert np.min(out['force_n'])>2000


def test_rear_reference_hysteresis_reversal_is_continuous():
    from ddevsim.strategies.shallow_press.force_preview import MappedForcePreview
    model=MappedForcePreview(np.full(4,.04),np.full(4,.05),np.array([1500,1500,3000,3000]))
    before=model.step(np.full(4,-.05),np.full(4,-.1),np.zeros(4),False)
    after=model.step(np.full(4,-.05+1e-8),np.full(4,.1),np.zeros(4),False)
    assert np.max(abs(before['passive_spring_n']-after['passive_spring_n']))<.01


def test_asymmetric_damper_tables_have_different_front_and_rear_extension_loads():
    from ddevsim.strategies.shallow_press.force_preview import damper_force
    assert damper_force(np.full(4,-.21))==pytest.approx([-946,-946,-2618,-2618])
    assert damper_force(np.full(4,.20))==pytest.approx([413,413,1145,1145])


def test_force_preview_configuration_is_explicit_and_keeps_legacy_defaults():
    from ddevsim.strategies.shallow_press.config import ShallowPressConfig
    c=ShallowPressConfig(suspension_ff_mode='mapped_spring')
    assert c.reference_velocity_limit_m_s==.25 and c.reference_acceleration_limit_m_s2==1.5
    assert ShallowPressConfig().suspension_ff_mode=='legacy'
    with pytest.raises(ValueError):ShallowPressConfig(suspension_ff_mode='instant_cancellation')


def test_mapped_strategy_requires_anchor_channels_but_legacy_does_not():
    from test_preview_control import controller,observation
    from ddevsim.strategies.shallow_press.native import NativePreviewBridge
    from ddevsim.strategies.shallow_press.controller import REQUIRED
    controller().step(observation(0.))
    mapped=controller(suspension_ff_mode='mapped_spring')
    with pytest.raises((KeyError,ValueError)):mapped.step(observation(0.))
    with pytest.raises(ValueError):NativePreviewBridge(mapped,REQUIRED)


def test_initialized_preview_never_uses_live_passive_force_to_cancel_feedback():
    from test_preview_control import controller,observation
    from ddevsim.runtime.contracts import Observation
    a=controller(suspension_ff_mode='mapped_passive');b=controller(suspension_ff_mode='mapped_passive')
    def sample(t,force):
        o=observation(t,101.5 if t>=3 else 99.)
        values=dict(o.values_si)
        for w in ('L1','R1','L2','R2'):values.update({'Fs_'+w:force,'CmpS_'+w:.05})
        return Observation(t,t,True,values)
    for t in np.arange(0,3,.02):
        a.step(sample(float(t),3000));b.step(sample(float(t),3000))
    for t in np.arange(3,4,.02):
        ca=a.step(sample(float(t),3000));cb=b.step(sample(float(t),-90000))
        assert ca.suspension_force_n==pytest.approx(cb.suspension_force_n)
    assert a.records[-1]['mapped_preview'] is not None


def test_mapped_inertia_respects_configured_wheel_mass():
    from ddevsim.strategies.shallow_press.force_preview import MappedForcePreview
    model=MappedForcePreview(np.full(4,.04),np.full(4,.05),np.full(4,3000.),80.)
    out=model.step(np.zeros(4),np.zeros(4),np.ones(4),True)
    assert out['inertia_force_n']*out['motion_ratio']==pytest.approx(np.full(4,-80.))
