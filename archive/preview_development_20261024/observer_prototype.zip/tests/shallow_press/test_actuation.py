import numpy as np
from ddevsim.strategies.shallow_press.config import ShallowPressConfig


def test_disturbance_observer_uses_spin_and_past_applied_torque():
    from ddevsim.strategies.shallow_press.actuation import WheelDisturbanceObserver
    observer=WheelDisturbanceObserver(inertia_kg_m2=1.3,filter_s=.03)
    # Known accelerating wheel: T=20, alpha=10 -> resistance=7 Nm.
    for t in np.arange(0,1,.001):
        estimate=observer.update(float(t),np.full(4,10*t),np.full(4,20),.001)
    assert np.allclose(estimate,7,atol=.02)
    previous=estimate.copy()
    assert np.array_equal(observer.update(float(t),np.full(4,999),np.full(4,999),.001),previous)


def test_observer_state_is_resettable_and_instance_local():
    from ddevsim.strategies.shallow_press.actuation import WheelDisturbanceObserver
    a=WheelDisturbanceObserver(1.3,.03);b=WheelDisturbanceObserver(1.3,.03)
    a.update(0,np.zeros(4),np.ones(4)*50,.001)
    assert np.array_equal(b.estimate,np.zeros(4))
