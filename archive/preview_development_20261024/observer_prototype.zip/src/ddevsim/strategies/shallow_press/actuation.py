"""Expert-two local wheel disturbance observer, using SI measurements only.

The motor loop is an explicit simulation assumption, separate from the 20 ms
preview/body loop. The inertia 1.3 kg m2 is IW(.9)+IT(.4) in the native echo.
No native tire force or future state is used by this observer.
"""
import math
import numpy as np


class WheelDisturbanceObserver:
    def __init__(self,inertia_kg_m2,filter_s):
        if inertia_kg_m2<=0 or filter_s<=0:raise ValueError('positive observer settings required')
        self.inertia=inertia_kg_m2;self.tau=filter_s
        self.last_stamp=None;self.last_spin=None;self.acceleration=np.zeros(4)
        self.estimate=np.zeros(4)

    def update(self,stamp,spin,applied_torque,step_s):
        if self.last_stamp is not None and stamp<=self.last_stamp+1e-10:return self.estimate.copy()
        spin=np.asarray(spin,float);applied_torque=np.asarray(applied_torque,float)
        if self.last_spin is not None:
            dt=stamp-self.last_stamp
            alpha=(spin-self.last_spin)/dt
            self.acceleration+=(1-math.exp(-dt/.01))*(alpha-self.acceleration)
            self.estimate+=(1-math.exp(-dt/self.tau))*(applied_torque-self.inertia*self.acceleration-self.estimate)
        self.last_stamp=stamp;self.last_spin=spin.copy()
        return self.estimate.copy()
