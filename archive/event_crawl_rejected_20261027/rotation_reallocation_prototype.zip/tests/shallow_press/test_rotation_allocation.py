import numpy as np


def test_rotation_assist_moves_torque_within_each_side_without_extra_net_drive():
    from ddevsim.strategies.shallow_press.traction import rebalance_for_rotation
    base=np.full(4,100.);loads=np.full(4,3300.);radii=np.full(4,.263)
    output=rebalance_for_rotation(base,[200.,180.,0.,0.],loads,radii,.7,500.)
    assert np.allclose(output,[300.,280.,-100.,-80.])
    assert np.array_equal(base,np.full(4,100.))
    assert output[[0,2]].sum()==base[[0,2]].sum()
    assert output[[1,3]].sum()==base[[1,3]].sum()


def test_rotation_assist_respects_both_donor_and_receiver_capacity():
    from ddevsim.strategies.shallow_press.traction import rebalance_for_rotation
    output=rebalance_for_rotation(np.full(4,80.),[250.,250.,0.,0.],np.full(4,3300.),np.full(4,.263),.7,100.)
    assert np.allclose(output,[100.,100.,60.,60.])
    output=rebalance_for_rotation(np.zeros(4),[0.,200.,0.,0.],[3300.,3300.,3300.,0.],np.full(4,.263),.7,500.)
    assert np.allclose(output,0.)  # no invented counter torque from airborne RR
