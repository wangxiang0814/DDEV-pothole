import numpy as np
import pytest
from test_preview_control import SCENE


def test_circle_reference_matches_flat_and_pit_floor_without_changing_physical_scene():
    from ddevsim.strategies.shallow_press.contact_reference import circle_plane
    points=np.array([[99.,-.63],[101.5,-.63],[101.5,.63],[103.,-.63]])
    out=circle_plane(points,points,SCENE)
    assert out[:,0]==pytest.approx([0.,-.04,0.,0.],abs=1e-10)
    assert out[:,1:]==pytest.approx(np.zeros((4,2)),abs=1e-9)


def test_circle_plane_has_correct_normal_and_support_radius_on_entry_corner():
    from ddevsim.strategies.shallow_press.contact_reference import circle_plane
    from ddevsim.strategies.shallow_press.preview import wheel_support_height
    scene=dict(SCENE,depth_m=.1);radius=.263
    points=np.array([[101.23,-.63]])
    initial=circle_plane(points,points,scene,radius)
    slope=initial[0,1];contact=points.copy();contact[0,0]+=radius*slope/np.sqrt(1+slope*slope)
    plane=circle_plane(points,contact,scene,radius)
    center_z=radius+wheel_support_height(points,scene,radius)[0]
    distance=np.hypot(points[0,0]-contact[0,0],center_z-plane[0,0])
    assert distance==pytest.approx(radius,abs=1e-6)
    assert slope<0 and plane[0,0]==pytest.approx(0.,abs=1e-5)
