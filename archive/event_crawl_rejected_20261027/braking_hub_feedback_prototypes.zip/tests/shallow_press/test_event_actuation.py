import numpy as np
from test_actuation import feedback


def test_airborne_sync_is_small_local_and_cannot_bypass_stale_unloading():
    from ddevsim.strategies.shallow_press.actuation import CrawlActuation
    from ddevsim.strategies.shallow_press.config import ShallowPressConfig
    c=ShallowPressConfig(policy='event_crawl');a=CrawlActuation(c);d=feedback()
    for w in ('L1','R1','L2','R2'):d['Fz_'+w]=0.;d['CmpT_'+w+'i']=0.;d['AVy_'+w]=1.3/.263
    context=dict(phases=['BYPASS','ENTRY','BYPASS','CLIMB'],airborne_sync_gain=50.,airborne_sync_limit_nm=30.)
    old=np.zeros(9)
    for t in np.arange(0,.1,.0005):
        u=a.step(float(t),float(t),d,np.zeros(9),None,{'friction':.7},.0005,event_context=context)
        assert max(abs(u[:4]-old[:4]))<=.50000001;old=u
    assert u[0]==u[2]==0 and -30<=u[1]<-20 and -30<=u[3]<-20
    for t in np.arange(.1,.3,.0005):u=a.step(float(t),0.,d,np.zeros(9),None,{'friction':.7},.0005,event_context=context)
    assert np.allclose(u,0.)


def test_geometric_hub_motion_does_not_look_like_spin_on_a_rolling_incline():
    from ddevsim.strategies.shallow_press.actuation import CrawlActuation
    from ddevsim.strategies.shallow_press.config import ShallowPressConfig
    outputs=[]
    for use_motion in (False,True):
        c=ShallowPressConfig(policy='event_crawl',event=dict(hub_motion_feedback=use_motion))
        a=CrawlActuation(c)
        for t in np.arange(0,.201,.0005):
            d=feedback();d['Vx']=.2
            for i,w in enumerate(('L1','R1','L2','R2')):
                x=10.+.2*t-(1.925 if i>1 else 0);y=.63 if i%2==0 else -.63;z=.5+.2*t
                d.update({'X_'+w:x,'Y_'+w:y,'Z_'+w:z,'Xctc_'+w+'i':x+.263/np.sqrt(2),
                    'Yctc_'+w+'i':y,'Zgnd_'+w+'i':z-.263/np.sqrt(2),'AVy_'+w:.2*np.sqrt(2)/.263})
            u=a.step(float(t),float(t),d,np.zeros(9),None,{'friction':.7},.0005)
        outputs.append(u[:4])
    assert np.max(abs(outputs[1]))<1e-6
    assert np.max(abs(outputs[0]))>5.
