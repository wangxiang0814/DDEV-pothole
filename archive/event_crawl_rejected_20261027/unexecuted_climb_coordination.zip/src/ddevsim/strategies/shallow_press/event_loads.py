"""Opt-in quasi-static climb unloading, with same-side axle load transfer.

Targets are scheduling assumptions, not measured contact-force guarantees.
The body, contact and finite actuator loops remain necessary.
"""
import math
import numpy as np
from .event_config import four


def climb_load_targets(anchor,x,y,scene,ratio):
    anchor=four(anchor);x=four(x);y=four(y)
    if not math.isfinite(ratio) or not 0<ratio<=1 or np.any(anchor<0):
        raise ValueError('positive bounded climb load ratio required')
    if ratio==1:return anchor.copy()
    end=scene['start_station_m']+scene['length_m']
    smooth=lambda z:(lambda q:q*q*(3-2*q))(np.clip(z,0.,1.))
    entering=smooth((x-(end-.263-.08))/.12)
    leaving=1-smooth((x-(end-.05))/.20)
    track=abs(y-scene['center_y_m'])<scene['width_m']/2-.05
    released=anchor*(1-ratio)*entering*leaving*track
    # FL<->RL and FR<->RR preserve each side's total nominal support.
    return anchor-released+released[[2,3,0,1]]
