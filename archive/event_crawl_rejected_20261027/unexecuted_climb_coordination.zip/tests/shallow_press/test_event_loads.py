import numpy as np
import pytest
from ddevsim.strategies.shallow_press.event_loads import climb_load_targets

SCENE=dict(start_station_m=100.,length_m=.8,width_m=3.,center_y_m=0.)

def test_climb_target_unloads_the_climbing_axle_and_retains_static_total_per_side():
    anchor=np.array([3300.,3100.,4000.,2800.]);x=np.array([100.65]*2+[98.73]*2)
    out=climb_load_targets(anchor,x,np.array([.63,-.63,.63,-.63]),SCENE,.6)
    assert np.allclose(out[:2],.6*anchor[:2])
    assert np.allclose(out[:2]+out[2:],anchor[:2]+anchor[2:])
    assert np.all(out>0)

def test_single_side_bypass_and_disabled_setting_leave_the_other_wheels_alone():
    anchor=np.full(4,3300.);x=np.array([100.65]*2+[98.73]*2);y=np.array([.63,-.63,.63,-.63])
    scene=dict(SCENE,width_m=.6,center_y_m=-.63)
    out=climb_load_targets(anchor,x,y,scene,.6)
    assert out[0]==out[2]==3300. and out[1]<3300. and out[3]>3300.
    assert np.array_equal(climb_load_targets(anchor,x,y,scene,1.),anchor)


def test_rear_climb_transfers_support_forward_without_swapping_vehicle_sides():
    anchor=np.array([3300.,3100.,4000.,2800.]);x=np.array([102.575]*2+[100.65]*2)
    out=climb_load_targets(anchor,x,np.array([.63,-.63,.63,-.63]),SCENE,.6)
    assert np.allclose(out[2:],anchor[2:]*.6)
    assert np.allclose(out[:2],anchor[:2]+.4*anchor[2:])

def test_transfer_is_smooth_and_finishes_after_the_lip():
    anchor=np.full(4,3300.);y=np.array([.63,-.63,.63,-.63])
    last=None
    for station in np.arange(100.3,101.2,.0001):
        x=np.array([station]*2+[station-1.925]*2)
        out=climb_load_targets(anchor,x,y,SCENE,.6)
        if last is not None:assert np.max(abs(out-last))<3.
        last=out
    assert np.array_equal(out,anchor)
    for ratio in (0.,1.01,float('nan')):
        with pytest.raises(ValueError):climb_load_targets(anchor,x,y,SCENE,ratio)


def test_fast_load_loop_does_not_cancel_climb_unloading_or_drop_support_transfer():
    from types import SimpleNamespace
    from ddevsim.strategies.shallow_press.config import ShallowPressConfig
    from ddevsim.strategies.shallow_press.fast_load import FastLoadFeedback
    c=ShallowPressConfig(policy='event_crawl',fast_load_gain=1.,fast_load_limit_n=4000.)
    # Prototype integration contract, before adding an active runtime option.
    settings=SimpleNamespace(**c.__dict__)
    settings.event=SimpleNamespace(climb_load_ratio=.6)
    loop=FastLoadFeedback(settings)
    anchor=np.full(4,3300.);j=np.full(4,.04);y=np.array([.63,-.63,.63,-.63])
    scene=dict(SCENE,edge_transition_m=.05)
    loop.step(0.,anchor,j,np.full(4,98.),y,scene,.002)
    out=loop.step(5.,anchor,j,np.array([100.65]*2+[98.73]*2),y,scene,.002)
    assert np.all(out[:2]<-1000.)
    assert np.all(out[2:]>1000.)
