"""Freeze four matched controller variants, then run at most two native workers."""
from pathlib import Path
import json,hashlib,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
r=Path.cwd();base=r/'evidence/shallow_event_crawl_20261026'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((base/'fixed_coverage/frozen_plan.json').read_text(encoding='utf-8'))
sources={n:sha(r/n) for n in old['source_sha256']}
module='src/ddevsim/strategies/shallow_press/event_loads.py';sources[module]=sha(r/module)
plans=[]
for policy in ('error_gated','preview'):
 for ratio in (1.,.6):
  slug='climb_%s_load%03d'%(policy,round(ratio*100));out=base/slug;out.mkdir(exist_ok=False)
  config=json.loads((base/'crest_release/config.json').read_text(encoding='utf-8'))
  config['cruise_kph']=3.;config['event'].update(climb_assist_policy=policy,climb_load_ratio=ratio)
  cp=out/'config.json';cp.write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
  rid='event_%s_wide_d10_a30_20261027_001'%slug
  args=['--case','wide','--depth-m','.1','--run-id',rid,'--config',str(cp.relative_to(r)),'--speed-kph','3','--crossing-kph','1','--approach-distance-m','12','--delay-s','.04','--motor-delay-s','.002','--duration-s','70']
  row=dict(case='wide',depth_m=.1,crossing_kph=1.,approach_kph=3.,kind=slug,run_id=rid,args=args)
  plan=dict(scope='MATCHED_CLIMB_ASSIST_AND_LOAD_COORDINATION_2X2_NOT_VALIDATED_RELEASE',config_path=str(cp.relative_to(r)),config_sha256=sha(cp),source_sha256=sources,cases=[row])
  pp=out/'frozen_plan.json';pp.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8');plans.append(pp)
def run(pp):
 code=subprocess.call([sys.executable,'scripts/run_shallow_preview_matrix.py','--plan',str(pp.relative_to(r)),'--workers','1'])
 if code:raise RuntimeError(str(pp)+' failed')
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,plans))
