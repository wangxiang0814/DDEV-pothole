"""Preview-only passive suspension approximation for tuned_ii_20261005.

Tables are copied from the original model (SHA496f280f...52ce), SI converted.
Fs inputs calibrate the flat anchor only. No measured passive-force cancellation.
Rear hysteresis and spline dampers are approximations, not native reproductions.
"""
import numpy as np

MAPPED_REQUIRED=tuple(p+w for p in ('Fs_','CmpS_') for w in ('L1','R1','L2','R2'))
SOURCE_MODEL_SHA256='496f280f0ef547b8c42ffb4e632184e511a007a8799ccd84b1ae02a8c20b52ce'
_J=np.array([0,.01,.02,.03])
_SEAT=(np.array([0,.0065144,.01368024,.0214977]),
       np.array([0,.00797,.016737,.026301]))
_REAR_COMP=np.array([[-150,-8068.01],[-135,-7364.99],[-120,-6640.757],[-105,-5893.547],
    [-90,-5123.626],[-75,-4331.68],[-60,-3517.91],[-45,-2681.44],[-30,-1819.8],[-15,-928.41],
    [0,0],[15,976.26],[30,2015.91],[45,3141.29],[60,4384.87],[75,5795.47],[90,7449.47],
    [105,9472.67],[120,12081.27],[135,15649.47],[150,20752.57]],float)
_REAR_EXT=np.array([[-150,-10879.73],[0,-1224.35],[15,-443.34],[30,388.38],[45,1288.69],
    [60,2283.55],[75,3412.03],[90,4735.27],[105,6353.77],[120,8440.67],[135,11295.27],[150,15377.67]],float)
_REAR_COMP[:,0]*=.001;_REAR_EXT[:,0]*=.001
_DV=np.array([-1.410,-.720,-.390,-.210,-.090,-.020,0,.020,.090,.200,.390,.760,1.160])
_DF=(np.array([-2644,-1814,-1227,-946,-532,-120,0,120,314,413,580,948,1351]),
     np.array([-7316,-5019,-3395,-2618,-1472,-333,0,333,870,1145,1607,2623,3740]))


def _four(value):
    a=np.asarray(value,float)
    if a.shape!=(4,) or not np.isfinite(a).all():raise ValueError('finite four-corner SI values required')
    return a


def _linear(x,xp,fp):
    indices=np.clip(np.searchsorted(xp,x,side='right')-1,0,len(xp)-2)
    slope=(fp[indices+1]-fp[indices])/(xp[indices+1]-xp[indices])
    return fp[indices]+(x-xp[indices])*slope,slope


def seat_kinematics(jounce):
    j=_four(jounce);g=np.zeros(4);mu=np.zeros(4)
    for begin,table in ((0,_SEAT[0]),(2,_SEAT[1])):
        g[begin:begin+2],mu[begin:begin+2]=_linear(j[begin:begin+2],_J,table)
    return g,mu


def damper_force(rate):
    """Piecewise-linear approximation of native SPLINE tables, N vs m/s."""
    rate=_four(rate);result=np.zeros(4)
    for begin,table in ((0,_DF[0]),(2,_DF[1])):
        result[begin:begin+2]=_linear(rate[begin:begin+2],_DV,table)[0]
    return result


class MappedForcePreview:
    transition_m=.006

    def __init__(self,jounce_m,compression_m,spring_n,wheel_mass_kg=40.):
        if not np.isfinite(wheel_mass_kg) or wheel_mass_kg<0:raise ValueError('invalid preview wheel mass')
        self.wheel_mass_kg=float(wheel_mass_kg)
        self.j0=_four(jounce_m).copy();self.s0=_four(compression_m).copy();self.f0=_four(spring_n).copy()
        self.g0,self.mu0=seat_kinematics(self.j0)
        self.previous_s=self.s0.copy();self.previous_f=self.f0.copy()
        self.anchor_s=self.s0.copy();self.anchor_f=self.f0.copy();self.direction=np.zeros(4,int)

    def step(self,road_m,road_rate_m_s,road_acceleration_m_s2,include_damper=False):
        r=_four(road_m);rd=_four(road_rate_m_s);rdd=_four(road_acceleration_m_s2)
        g,mu=seat_kinematics(self.j0+r);s=self.s0+g-self.g0
        f=self.f0+30000*(s-self.s0)
        for i in (2,3):
            delta=s[i]-self.previous_s[i]
            direction=0 if abs(delta)<1e-9 else (1 if delta>0 else -1)
            if direction and direction!=self.direction[i]:
                self.direction[i]=direction;self.anchor_s[i]=self.previous_s[i];self.anchor_f[i]=self.previous_f[i]
            table=_REAR_COMP if self.direction[i]>=0 else _REAR_EXT
            nominal=_linear(s[i],table[:,0],table[:,1])[0]
            anchored=_linear(self.anchor_s[i],table[:,0],table[:,1])[0]
            f[i]=nominal+(self.anchor_f[i]-anchored)*np.exp(-abs(s[i]-self.anchor_s[i])/self.transition_m)
        spring=self.mu0*self.f0/mu-f
        damping=np.zeros(4) if not include_damper else -damper_force(rd)/mu
        inertia=np.zeros(4) if not include_damper else -self.wheel_mass_kg*rdd/mu
        self.previous_s=s.copy();self.previous_f=f.copy()
        return dict(force_n=spring+damping+inertia,spring_force_n=spring,
            damping_force_n=damping,inertia_force_n=inertia,passive_spring_n=f,
            motion_ratio=mu,predicted_compression_m=s,
            assumptions='REFERENCE_PATH_HYSTERESIS_6MM_AND_LINEARIZED_DAMPER_SPLINE_NOT_CALIBRATED')
