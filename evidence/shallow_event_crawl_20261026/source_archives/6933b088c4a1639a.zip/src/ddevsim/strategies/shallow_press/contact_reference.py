"""Unadopted low-speed rigid-circle contact-plane reference, no MF-Swift.

Same physical road and tire coefficients. Longitudinal rigid geometry only:
no belt dynamics, finite tread/footprint, calibrated enveloping or safety claim.
Plane imports use previous native state (one integration step causal delay).
"""
import numpy as np
from .preview import wheel_support_height

WHEELS=('L1','R1','L2','R2')
GROUND_IMPORTS=tuple(root+w+'i' for root in ('IMP_ZGND_','IMP_DZDX_','IMP_DZDY_') for w in WHEELS)


def circle_plane(points,contact_points,scene,radius=.263):
    p=np.asarray(points,float);q=np.asarray(contact_points,float)
    if p.ndim!=2 or p.shape[1]!=2 or q.shape!=p.shape or not np.isfinite(np.r_[p.ravel(),q.ravel()]).all():
        raise ValueError('finite matching contact coordinates required')
    eps=.0005;dx=np.array([eps,0]);dy=np.array([0,eps]);n=len(p)
    h=wheel_support_height(np.concatenate((p,p+dx,p-dx,p+dy,p-dy)),scene,radius)
    gradient=np.column_stack(((h[n:2*n]-h[2*n:3*n])/(2*eps),(h[3*n:4*n]-h[4*n:])/(2*eps)))
    center=radius+h[:n]
    intercept=center-radius*np.sqrt(1+np.sum(gradient*gradient,axis=1))
    z=intercept+np.sum(gradient*(q-p),axis=1)
    return np.column_stack((z,gradient))


class CirclePlaneReference:
    def __init__(self,names,scene):
        self.index={n:i for i,n in enumerate(names)};self.scene=dict(scene)
        required=[p+w+s for p,s in (('X_',''),('Y_',''),('Xctc_','i'),('Yctc_','i')) for w in WHEELS]
        if any(n not in self.index for n in required):raise ValueError('contact reference requires native contact coordinates')

    def __call__(self,exports):
        get=lambda p,s='':np.array([exports[self.index[p+w+s]] for w in WHEELS])
        points=np.column_stack((get('X_'),get('Y_')))
        contacts=np.column_stack((get('Xctc_','i'),get('Yctc_','i')))
        return tuple(circle_plane(points,contacts,self.scene).T.ravel())
